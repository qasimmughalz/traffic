export const Counter=()=>{
    return(
        <div>
            <h1>I am in counter</h1>
          
        </div>
    )
}